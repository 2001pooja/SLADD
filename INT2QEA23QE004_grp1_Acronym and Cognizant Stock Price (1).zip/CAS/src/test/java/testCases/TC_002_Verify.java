package testCases;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.swing.text.Document;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.devtools.idealized.Network.UserAgent;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

import net.bytebuddy.asm.Advice.Argument;
import pageObjects.Acronyms;
import pageObjects.HomePage;
import testBase.BaseClass;
import utilityFiles.ExcelUtils;
import utilityFiles.Screenshots;

public class TC_002_Verify extends TC_001_UserInfo {
	
	// method for acronym page verification
	@Test(priority = 2)
	public void verify() throws InterruptedException, IOException {
		Acronyms ac = new Acronyms(driver);
		ac.verify();
		Thread.sleep(4000);
		
		
		String act_title = driver.getTitle();
		System.out.println("the actual title: "+act_title);
		String exp_title = "Acronyms";
		Assert.assertEquals(act_title, exp_title);
	}
	
	// method to get the acronyms name and store the details in excel sheet
	@Test(priority = 3)
	public void getAcronyms() throws IOException, InterruptedException {
		
        List<WebElement> acronyms = driver.findElements(By.xpath("//tbody/tr/td[1]"));
        System.out.println(acronyms.size());
    	for(int i=0;i<acronyms.size();i++) {
    		System.out.println(acronyms.get(i).getText());
    	
    		String data = acronyms.get(i).getText();
    	    String file = System.getProperty("user.dir")+"\\testData\\data@CAS.xlsx";
    	    utilityFiles.ExcelUtils.setCellData(file, "Sheet2", i, 0, data);
    	}
    	
    	
    	
    	
    	
    	
    	Screenshots sc = new Screenshots();
    	HomePage h = new HomePage(driver);
    	
    	driver.findElement(By.xpath("//div[@class='ei_u_9f38462c ei_w_9f38462c gz_w_9f38462c']")).click();
    	
    	for(int j=0;j<8;j++) {
    		
    	for(int k=0;k<5;k++) {
    		h.scrolldown();   		
    	}
    	Thread.sleep(1000);
    	sc.screenshot("Screen"+j+".png");
    	}
	}
}






