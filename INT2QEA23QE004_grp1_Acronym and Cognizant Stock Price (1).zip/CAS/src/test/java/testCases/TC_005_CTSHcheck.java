package testCases;

import java.util.List;

import org.checkerframework.checker.units.qual.kg;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import pageObjects.CTSH;


@Listeners(utilityFiles.ExtentReportManager.class)
public class TC_005_CTSHcheck extends TC_004_Get_NASDAQ {
	
	// method to check the current stock price is present in previous recods or not
	@Test(priority = 9)
	public void check() throws InterruptedException {
		CTSH ct = new CTSH(driver);
		ct.getPreviousStock();
		
		double curr = cogprice;
		double arr[] = new double[260];
		List<WebElement> list = driver.findElements(By.xpath("//tbody/tr/td[5]/span"));
		for(int i=0;i<list.size();i++) {
			String text = list.get(i).getText();
			arr[i] = Double.parseDouble(text);
		}
		
//		for(int j=0;j<arr.length;j++) {
//			System.out.println(arr[j]);
//		}
		for(int k=0;k<arr.length;k++) {
			if(arr[k] == curr) {
				System.out.println("match found: "+(k+1));
			}
		}
		
		
		Thread.sleep(5000);
	}
}
