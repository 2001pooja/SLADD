package pageObjects;

import org.openqa.selenium.WebDriver;

public class CTSH extends BasePage {

	
	//constructor
	public CTSH(WebDriver driver) {
		super(driver);
	}
	
	//locators
	
	
	//Actions
	// method for CTSH page
	public void getPreviousStock() {
		driver.get("https://finance.yahoo.com/quote/CTSH/history");
	}

}
