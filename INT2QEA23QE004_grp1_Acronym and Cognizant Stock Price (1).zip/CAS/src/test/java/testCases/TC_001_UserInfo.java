package testCases;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import pageObjects.HomePage;
import testBase.BaseClass;
import utilityFiles.Screenshots;

public class TC_001_UserInfo extends BaseClass {
	
	
	// method to get the name,email info and the screenshot
	@Test(priority = 1)
	public void verifyInfo() throws InterruptedException {
		HomePage hp = new HomePage(driver);
		hp.openProfileInfo();
		
		String name = driver.findElement(By.xpath("//div[@id='mectrl_currentAccount_primary']")).getText();
		System.out.println(name);
		
		String email = driver.findElement(By.xpath("//div[@id='mectrl_currentAccount_secondary']")).getText();
		System.out.println(email);
		
		Screenshots sc = new Screenshots();
		try {
			sc.screenshot("profile.png");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
