package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class Acronyms extends BasePage {

	public Acronyms(WebDriver driver) {
		super(driver);
	}
	
	//locators
	By drp = By.xpath("//button[@name='Company']");
	By val = By.xpath("//span[normalize-space()='Acronyms']");
	
	//action methods
	// method to verify it is acronym page or not
	public void verify() throws InterruptedException {
		driver.findElement(drp).click();
		Thread.sleep(3000);
		if(driver.findElement(drp).isDisplayed()) {
			Assert.assertTrue(true);
		}
		driver.findElement(val).click();
	}
	
	// method for navigating the previous page
	public void navigateBack() throws InterruptedException {
		driver.navigate().back();
		Thread.sleep(5000);
	}
	
	
}
